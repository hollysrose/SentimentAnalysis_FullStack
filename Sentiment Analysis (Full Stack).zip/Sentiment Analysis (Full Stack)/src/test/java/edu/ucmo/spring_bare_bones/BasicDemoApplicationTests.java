package edu.ucmo.spring_bare_bones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
